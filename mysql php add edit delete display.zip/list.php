<a href="add.php" class="button">Add Project</a>
<?php 
	include 'connection.php';

	$query = "select * from projects";
	$result = mysql_query($query);

	echo "<table border='1'>";
	echo "<tr><td>ID</td><td>Name</td><td>Description</td><td>Site</td><td>Status</td><td>Action</td></tr>";
	while ($row = mysql_fetch_array($result)) {
		echo "<tr>";
		echo "<td>".$row['id']."</td><td>".$row['name']."</td><td>".$row['description']."</td><td>".$row['site']."</td><td>".$row['status']."</td><td> <a href='edit.php?id=".$row['id']."'>Edit</a> <a  href='delete_action.php?id=".$row['id']."'>
		Delete</a> </td>";
		echo "</tr>";

	}
	echo "<table>";
?>

<style>
.button{
	color: #FFFFFF !important;
    background: #4CAF50 !important;
    border: none;
    display: inline-block;
    padding: 8px 16px;
    vertical-align: middle;
    overflow: hidden;
    text-decoration: none;
    color: inherit;
    background-color: inherit;
    text-align: center;
    cursor: pointer;
    white-space: nowrap;
    margin-bottom: 10px;
    float: right;
}

table {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style> 