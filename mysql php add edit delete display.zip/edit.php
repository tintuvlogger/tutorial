<?php 
	require 'connection.php';
	if(!isset($_GET['id'])){
		die("Id not supplied");
	}
	$id = $_GET['id'];
	$query = "select * from projects where id = $id";
	$result = mysql_query($query);
	$row = mysql_fetch_assoc($result);
?>

<form method="post" onsubmit="return validation();" action="edit_action.php">
	<input type="hidden" name="id" value="<?php echo $row['id'];?>">
	<input type="text" name="name" value="<?php echo $row['name'];?>" id="name" placeholder="Project name"> <br><br>
	<textarea placeholder="Description" name="description" id="description" cols="30" rows="10"><?php echo $row['description'];?></textarea><br><br>
	<input type="text" value="<?php echo $row['site'];?>" placeholder="site" name="site" id="site"><br><br>
	<select name="status" id="status">
		<option value="-1">Select status</option>
		<option value="0">Not active</option>
		<option value="1">Active</option>
	</select>
	<br><br>
	<input type="submit" value="Save">
</form>

<script>
	// set the status with javascript 
	document.getElementById("status").value=<?php echo $row['status'];?>;


	function validation(){
		 var return_value = false;
		 if(document.getElementById("name").value==""){
		 	 alert("Please select name");
		 }
		 else if(document.getElementById("description").value==""){
		 	 alert("Please select description");
		 }
		 else if(document.getElementById("site").value==""){
		 	 alert("Please select site");
		 }
		 else if(document.getElementById("status").value==-1){
		 	 alert("Please select status");
		 }
		 else {
		 	return_value = true;
		 }
		 return return_value;
	}


</script> 