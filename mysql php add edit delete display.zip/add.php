<!DOCTYPE html>
<html>
<head>
	<title>Mysql Operations with php</title>
</head>
<body>

<a href="list.php">Project List</a><br><br>


<form method="post" onsubmit="return validation();" action="add_action.php">
	<input type="text" name="name" id="name" placeholder="Project name"> <br><br>
	<textarea placeholder="Description" name="description" id="description" cols="30" rows="10"></textarea><br><br>
	<input type="text" placeholder="site" name="site" id="site"><br><br>
	<select name="status" id="status">
		<option value="-1">Select status</option>
		<option value="0">Not active</option>
		<option value="1">Active</option>
	</select>
	<br><br>
	<input type="submit" value="Save">
</form>


<script type="text/javascript">
	
	function validation(){
		 var return_value = false;
		 if(document.getElementById("name").value==""){
		 	 alert("Please select name");
		 }
		 else if(document.getElementById("description").value==""){
		 	 alert("Please select description");
		 }
		 else if(document.getElementById("site").value==""){
		 	 alert("Please select site");
		 }
		 else if(document.getElementById("status").value==-1){
		 	 alert("Please select status");
		 }
		 else {
		 	return_value = true;
		 }
		 return return_value;
	}

</script>


</body>
</html>