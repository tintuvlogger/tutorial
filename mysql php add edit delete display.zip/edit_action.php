<?php 
	require 'connection.php';
	if(!empty($_POST)){

		$id = $_POST['id'];
		$name = mysql_real_escape_string($_POST['name']);
		$description = mysql_real_escape_string($_POST['description']);
		$site = mysql_real_escape_string($_POST['site']);
		$status = mysql_real_escape_string($_POST['status']);

		echo $query = "update projects set name='$name',description='$description',site='$site',status='$status' where id = $id";
		mysql_query($query);
		header("Location:list.php");

	}	
?>