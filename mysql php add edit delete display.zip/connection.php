<?php 
error_reporting(E_ERROR | E_PARSE);
	$link = mysql_connect('localhost', 'root', '');
	if (!$link) {
	    die('Not connected : ' . mysql_error());
	}

	// make my_db the current db
	$db_selected = mysql_select_db('dplus_db', $link);
	if (!$db_selected) {
	    die ('Can\'t use foo : ' . mysql_error());
	}
?>