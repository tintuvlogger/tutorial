<?php 
	require 'connection.php';
	if(!isset($_GET['id'])){
		die("Id not supplied");
	}
	$id = $_GET['id'];
	$query = "delete from projects where id =".$id;
	mysql_query($query);
	header("Location:list.php");
?>