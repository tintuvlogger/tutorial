<?php 
	require 'connection.php';
	if(!empty($_POST)){

		$name = mysql_real_escape_string($_POST['name']);
		$description = mysql_real_escape_string($_POST['description']);
		$site = mysql_real_escape_string($_POST['site']);
		$status = mysql_real_escape_string($_POST['status']);

		echo $query = "insert into projects(name,description,site,status) values('$name','$description','$stie',$status)";
		mysql_query($query);
		header("Location:list.php");

	}	
?>